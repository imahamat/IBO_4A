package demoJSF;

import java.io.Serializable;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

@ManagedBean //register the class student as JSF resource
@RequestScoped // creates an instance of Student for each user request
public class Student{


String studentID;
String name;
long classID;

public Student() {	}

public String getStudentID() {
return studentID;
}
public void setStudentID(String studentID) {
this.studentID = studentID;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public long getClassID() {
return classID;
}
public void setClassID(long classID) {
this.classID = classID;
}

public void validateStudentID(FacesContext context, UIComponent component, Object value) throws ValidatorException{

if(value==null){
return;}

String data=value.toString();
if(!data.startsWith("STU")){
FacesMessage message= new FacesMessage("Student ID should start with STU");
throw new ValidatorException(message);
}
}
}
